import os
import re
import json
import logging
from functools import wraps
from flask import Flask, request, jsonify, render_template, send_file
from flask_cors import CORS
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import requests
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.enums import TA_JUSTIFY, TA_CENTER
from reportlab.lib.colors import HexColor
from io import BytesIO
from datetime import datetime
from typing import Dict, Tuple, Optional

# ---------------------------
# Configuration
# ---------------------------
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": "*"}})

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Rate limiting to prevent abuse
limiter = Limiter(
    app=app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"],
    storage_uri="memory://"
)

# Configuration from environment variables
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
app.config['GROQ_API_URL'] = os.getenv('GROQ_API_URL', 'https://api.groq.com/openai/v1/chat/completions')
app.config['GROQ_API_KEY'] = os.getenv('GROQ_API_KEY', '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')
app.config['REQUEST_TIMEOUT'] = int(os.getenv('REQUEST_TIMEOUT', '30'))
app.config['MAX_TEXT_LENGTH'] = int(os.getenv('MAX_TEXT_LENGTH', '50000'))

# ---------------------------
# Constants
# ---------------------------
STOP_WORDS = set([
    'the', 'and', 'is', 'in', 'to', 'of', 'a', 'for', 'that', 'on', 'with',
    'as', 'are', 'be', 'by', 'or', 'this', 'it', 'an', 'from', 'which', 'at',
    'not', 'but', 'has', 'have', 'had', 'was', 'were', 'been', 'will', 'would'
])

SUMMARY_LEVELS = {
    'short': {'sentences': 2, 'description': 'Brief Overview'},
    'medium': {'sentences': 4, 'description': 'Standard Summary'},
    'detailed': {'sentences': 7, 'description': 'Comprehensive Analysis'}
}

# ---------------------------
# Utility Functions
# ---------------------------
def validate_input(func):
    """Decorator to validate common input parameters"""
    @wraps(func)
    def wrapper(*args, **kwargs):
        payload = request.get_json() or {}
        
        # Validate text
        text = payload.get('text', '').strip()
        if 'text' in payload and not text:
            return jsonify({'error': 'Text cannot be empty.'}), 400
        
        if 'text' in payload and len(text) > app.config['MAX_TEXT_LENGTH']:
            return jsonify({
                'error': f'Text exceeds maximum length of {app.config["MAX_TEXT_LENGTH"]} characters.'
            }), 400
        
        # Validate level
        level = payload.get('level', 'medium')
        if level not in SUMMARY_LEVELS:
            return jsonify({
                'error': f'Invalid level. Choose from: {", ".join(SUMMARY_LEVELS.keys())}'
            }), 400
        
        return func(*args, **kwargs)
    return wrapper


def sanitize_text(text: str) -> str:
    """Sanitize input text to prevent injection attacks"""
    # Remove any potentially dangerous characters or patterns
    text = re.sub(r'[^\x00-\x7F]+', ' ', text)  # Remove non-ASCII
    text = re.sub(r'\s+', ' ', text)  # Normalize whitespace
    return text.strip()


# ---------------------------
# Summarization Functions
# ---------------------------
def simple_summarize(text: str, level: str = 'medium') -> str:
    """
    Local extractive summarizer using word frequency scoring.
    Falls back when API is unavailable.
    """
    try:
        s_count = SUMMARY_LEVELS[level]['sentences']
        
        # Split into sentences
        sentences = re.split(r'(?<=[.!?])\s+', text.strip())
        sentences = [s.strip() for s in sentences if s.strip()]
        
        if len(sentences) <= s_count:
            return ' '.join(sentences)
        
        # Calculate word frequencies
        words = re.findall(r"\b\w+\b", text.lower())
        freq = {}
        for w in words:
            if w not in STOP_WORDS and len(w) >= 3:
                freq[w] = freq.get(w, 0) + 1
        
        # Score sentences
        scores = []
        for i, sentence in enumerate(sentences):
            words_in_sentence = re.findall(r"\b\w+\b", sentence.lower())
            score = sum(freq.get(w, 0) for w in words_in_sentence)
            # Boost score for sentences containing legal keywords
            legal_keywords = ['shall', 'must', 'required', 'obligated', 'entitled', 'agree']
            if any(keyword in sentence.lower() for keyword in legal_keywords):
                score *= 1.2
            scores.append((score, i, sentence))
        
        # Select top sentences and maintain original order
        scores.sort(reverse=True)
        top_sentences = sorted(scores[:s_count], key=lambda x: x[1])
        return ' '.join(s for _, _, s in top_sentences)
    
    except Exception as e:
        logger.error(f"Error in simple_summarize: {str(e)}")
        return "Error generating summary. Please try again."


def legal_safety_postprocess(summary: str, source_text: str) -> str:
    """
    Post-process summary to preserve legal qualifiers and conditions.
    Prevents turning conditional legal duties into absolute ones.
    """
    try:
        # Preserve conditional language
        conditional_patterns = [
            (r"(must|shall|should)\s+give\s+(the\s+)?other\s+party\s+notice",
             r"\1 give \2other party reasonable prior notice where legally permissible"),
            (r"(is|are)\s+required\s+to(?!\s+where)",
             r"\1 required to, where applicable,"),
        ]
        
        # Check if source contains legal qualifiers
        legal_qualifiers = ['where legally permissible', 'unless otherwise agreed', 
                          'at the discretion of', 'subject to', 'provided that']
        
        has_qualifiers = any(q.lower() in source_text.lower() for q in legal_qualifiers)
        
        if has_qualifiers:
            for pattern, replacement in conditional_patterns:
                summary = re.sub(pattern, replacement, summary, flags=re.IGNORECASE)
        
        return summary
    
    except Exception as e:
        logger.error(f"Error in legal_safety_postprocess: {str(e)}")
        return summary


def summarize_with_groq(text: str, level: str) -> Tuple[str, Optional[str]]:
    """
    Summarize text using Groq API.
    Returns (summary, error_message)
    """
    try:
        headers = {
            'Authorization': f'Bearer {app.config["GROQ_API_KEY"]}',
            'Content-Type': 'application/json'
        }
        
        level_desc = SUMMARY_LEVELS[level]['description']
        
        body = {
            "model": "llama-3.3-70b-versatile",
            "messages": [
                {
                    "role": "system",
                    "content": (
                        "You are an expert legal document analyst that summarizes complex legal text "
                        "into clear, plain English while preserving critical legal nuances. "
                        "Always maintain:\n"
                        "- Legal conditions and qualifiers (e.g., 'where legally permissible', 'unless otherwise agreed')\n"
                        "- Conditional obligations (do NOT convert 'may' to 'must')\n"
                        "- Important exceptions and disclaimers\n"
                        "- Key parties, dates, and amounts\n"
                        "Avoid legal jargon where possible, but never simplify in ways that change legal meaning."
                    )
                },
                {
                    "role": "user",
                    "content": (
                        f"Provide a {level_desc.lower()} of this legal document. "
                        f"Use plain language but preserve all critical legal conditions:\n\n{text}"
                    )
                }
            ],
            "temperature": 0.3,  # Lower temperature for more consistent legal summaries
            "max_tokens": 1000
        }
        
        response = requests.post(
            app.config['GROQ_API_URL'],
            headers=headers,
            json=body,
            timeout=app.config['REQUEST_TIMEOUT']
        )
        response.raise_for_status()
        
        result = response.json()
        summary = result['choices'][0]['message']['content']
        
        return summary, None
    
    except requests.exceptions.Timeout:
        return "", "Request timed out. Please try again."
    
    except requests.exceptions.RequestException as e:
        logger.error(f"Groq API error: {str(e)}")
        return "", f"API error: {str(e)}"
    
    except Exception as e:
        logger.error(f"Unexpected error in summarize_with_groq: {str(e)}")
        return "", "Unexpected error occurred."


# ---------------------------
# PDF Generation
# ---------------------------
def generate_pdf(summary_text: str, level: str, metadata: Optional[Dict] = None) -> BytesIO:
    """
    Generate a professionally formatted PDF document.
    """
    try:
        buffer = BytesIO()
        
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=50
        )
        
        elements = []
        styles = getSampleStyleSheet()
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=28,
            textColor=HexColor('#78350f'),
            alignment=TA_CENTER,
            spaceAfter=10,
            fontName='Helvetica-Bold',
            letterSpacing=2
        )
        
        subtitle_style = ParagraphStyle(
            'CustomSubtitle',
            parent=styles['Normal'],
            fontSize=14,
            alignment=TA_CENTER,
            textColor=HexColor('#f59e0b'),
            spaceAfter=30,
            fontName='Helvetica-Bold'
        )
        
        meta_style = ParagraphStyle(
            'MetaStyle',
            parent=styles['Normal'],
            fontSize=9,
            alignment=TA_CENTER,
            textColor=HexColor('#57534e'),
            spaceAfter=20
        )
        
        body_style = ParagraphStyle(
            'CustomBody',
            parent=styles['BodyText'],
            fontSize=11,
            leading=18,
            alignment=TA_JUSTIFY,
            textColor=HexColor('#1c1917'),
            spaceAfter=12
        )
        
        heading_style = ParagraphStyle(
            'CustomHeading',
            parent=styles['Heading2'],
            fontSize=14,
            textColor=HexColor('#92400e'),
            spaceAfter=12,
            spaceBefore=20
        )
        
        # Build document
        elements.append(Paragraph("⚖️ LEGALEASE", title_style))
        elements.append(Paragraph("Legal Document Summary Report", subtitle_style))
        
        # Metadata
        date_str = datetime.now().strftime("%B %d, %Y at %I:%M %p")
        level_desc = SUMMARY_LEVELS[level]['description']
        
        meta_text = f"<b>Summary Level:</b> {level_desc} | <b>Generated:</b> {date_str}"
        if metadata:
            if 'document_length' in metadata:
                meta_text += f" | <b>Source Length:</b> {metadata['document_length']:,} characters"
        
        elements.append(Paragraph(meta_text, meta_style))
        elements.append(Spacer(1, 0.3 * inch))
        
        # Summary content
        elements.append(Paragraph("📝 Summary", heading_style))
        
        # Sanitize and format summary text
        clean_text = summary_text.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
        
        # Split into paragraphs
        paragraphs = clean_text.split('\n')
        for para in paragraphs:
            if para.strip():
                elements.append(Paragraph(para.strip(), body_style))
                elements.append(Spacer(1, 0.1 * inch))
        
        # Footer
        elements.append(Spacer(1, 0.5 * inch))
        footer_style = ParagraphStyle(
            'Footer',
            parent=styles['Normal'],
            fontSize=8,
            textColor=HexColor('#9ca3af'),
            alignment=TA_CENTER,
            borderPadding=10
        )
        elements.append(Paragraph(
            "Generated by LEGALEASE • This summary is for informational purposes only and does not constitute legal advice.",
            footer_style
        ))
        
        doc.build(elements)
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Error generating PDF: {str(e)}")
        raise


# ---------------------------
# Routes
# ---------------------------
@app.route('/')
def index():
    """Serve the main application page"""
    return render_template('index.html')


@app.route('/health')
def health_check():
    """Health check endpoint for monitoring"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'version': '2.0.0'
    })


@app.route('/summarize', methods=['POST'])
@limiter.limit("10 per minute")
@validate_input
def summarize_endpoint():
    """
    Main summarization endpoint.
    Accepts JSON with 'text' and optional 'level' fields.
    """
    try:
        payload = request.get_json()
        text = sanitize_text(payload.get('text', ''))
        level = payload.get('level', 'medium')
        
        logger.info(f"Summarization request: level={level}, text_length={len(text)}")
        
        # Try Groq API first
        summary, error = summarize_with_groq(text, level)
        
        # Fallback to local summarizer if API fails
        if error:
            logger.warning(f"Groq API failed, using fallback: {error}")
            summary = simple_summarize(text, level)
            used_fallback = True
        else:
            used_fallback = False
        
        # Apply legal safety post-processing
        summary = legal_safety_postprocess(summary, text)
        
        response = {
            'summary': summary,
            'level': level,
            'timestamp': datetime.now().isoformat()
        }
        
        if used_fallback:
            response['warning'] = 'Used local summarizer due to API unavailability'
        
        return jsonify(response), 200
    
    except Exception as e:
        logger.error(f"Error in summarize_endpoint: {str(e)}")
        return jsonify({
            'error': 'An unexpected error occurred. Please try again.',
            'details': str(e) if app.debug else None
        }), 500


@app.route('/download-pdf', methods=['POST'])
@limiter.limit("5 per minute")
def download_pdf():
    """
    Generate and download a PDF of the summary.
    Accepts JSON with 'summary' and 'level' fields.
    """
    try:
        payload = request.get_json() or {}
        summary = payload.get('summary', '').strip()
        level = payload.get('level', 'medium')
        
        if not summary:
            return jsonify({'error': 'No summary provided.'}), 400
        
        if level not in SUMMARY_LEVELS:
            return jsonify({'error': 'Invalid summary level.'}), 400
        
        logger.info(f"PDF generation request: level={level}, summary_length={len(summary)}")
        
        # Generate PDF with metadata
        metadata = {
            'document_length': len(summary)
        }
        pdf_buffer = generate_pdf(summary, level, metadata)
        
        # Generate filename
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f'legalease_summary_{level}_{timestamp}.pdf'
        
        return send_file(
            pdf_buffer,
            mimetype='application/pdf',
            as_attachment=True,
            download_name=filename
        )
    
    except Exception as e:
        logger.error(f"Error in download_pdf: {str(e)}")
        return jsonify({
            'error': 'Failed to generate PDF. Please try again.',
            'details': str(e) if app.debug else None
        }), 500


@app.errorhandler(413)
def request_entity_too_large(error):
    """Handle file size limit exceeded"""
    return jsonify({
        'error': 'Request too large. Maximum size is 16MB.'
    }), 413


@app.errorhandler(429)
def ratelimit_handler(error):
    """Handle rate limit exceeded"""
    return jsonify({
        'error': 'Rate limit exceeded. Please try again later.'
    }), 429


@app.errorhandler(500)
def internal_error(error):
    """Handle internal server errors"""
    logger.error(f"Internal server error: {str(error)}")
    return jsonify({
        'error': 'Internal server error. Please try again later.'
    }), 500


# ---------------------------
# Main
# ---------------------------
if __name__ == '__main__':
    # Validate required environment variables
    if not app.config['GROQ_API_KEY'] or app.config['GROQ_API_KEY'].startswith('gsk_'):
        logger.warning("⚠️  Using default API key. Set GROQ_API_KEY environment variable in production!")
    
    # Run application
    port = int(os.getenv('PORT', '5000'))
    debug_mode = os.getenv('FLASK_ENV') == 'development'
    
    logger.info(f"Starting LEGALEASE server on port {port} (debug={debug_mode})")
    app.run(host='0.0.0.0', port=port, debug=debug_mode)