const btn = document.getElementById('summarizeBtn');
const downloadBtn = document.getElementById('downloadBtn');
const input = document.getElementById('inputText');
const output = document.getElementById('output');
const level = document.getElementById('level');

let currentSummary = '';

async function summarize() {
    const text = input.value.trim();
    
    if (!text) { 
        output.textContent = '⚠️ Please paste a legal document first to generate a summary.';
        output.style.color = '#d97706';
        downloadBtn.style.display = 'none';
        return;
    }
    
    // Update button state
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span class="btn-icon">⏳</span>Processing...';
    btn.disabled = true;
    
    output.textContent = '✨ Analyzing your document and generating a plain-language summary...';
    output.style.color = '#78350f';
    downloadBtn.style.display = 'none';

    try {
        const res = await fetch('/summarize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text, level: level.value })
        });

        if (!res.ok) {
            const err = await res.json().catch(() => ({ error: 'Server error' }));
            output.textContent = '❌ Error: ' + (err.error || 'Unknown error occurred. Please try again.');
            output.style.color = '#dc2626';
            return;
        }

        const data = await res.json();
        currentSummary = data.summary || 'No summary returned.';
        output.textContent = currentSummary;
        output.style.color = '#1c1917';
        
        // Show download button after successful summary
        if (currentSummary && currentSummary !== 'No summary returned.') {
            downloadBtn.style.display = 'flex';
            
            // Add subtle animation
            downloadBtn.style.animation = 'fadeIn 0.5s ease';
        }
    } catch (e) {
        output.textContent = '🔌 Network error: ' + e.message + '. Please check your connection and try again.';
        output.style.color = '#dc2626';
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
}

async function downloadPDF() {
    if (!currentSummary) {
        alert('⚠️ Please generate a summary first before downloading.');
        return;
    }
    
    const originalText = downloadBtn.innerHTML;
    downloadBtn.innerHTML = '<span class="btn-icon">⏳</span>Creating PDF...';
    downloadBtn.disabled = true;
    
    try {
        console.log('Sending download request...');
        
        const res = await fetch('/download-pdf', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ 
                summary: currentSummary, 
                level: level.value 
            })
        });
        
        console.log('Response status:', res.status);
        
        if (!res.ok) {
            const err = await res.json().catch(() => ({ error: 'PDF generation failed' }));
            alert('❌ Error: ' + (err.error || 'Unknown error occurred'));
            return;
        }
        
        // Get the PDF blob
        const blob = await res.blob();
        console.log('Blob received, size:', blob.size);
        
        // Create download link
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = `legalease_summary_${new Date().getTime()}.pdf`;
        
        // Append to body, click, and cleanup
        document.body.appendChild(a);
        a.click();
        
        // Cleanup
        setTimeout(() => {
            window.URL.revokeObjectURL(url);
            document.body.removeChild(a);
            console.log('Download complete');
        }, 100);
        
        // Show success message briefly
        downloadBtn.innerHTML = '<span class="btn-icon">✅</span>Downloaded!';
        setTimeout(() => {
            downloadBtn.innerHTML = originalText;
        }, 2000);
        
    } catch (e) {
        console.error('Download error:', e);
        alert('🔌 Network error: ' + e.message);
    } finally {
        setTimeout(() => {
            downloadBtn.disabled = false;
            if (downloadBtn.innerHTML.includes('Downloaded!')) {
                downloadBtn.innerHTML = originalText;
            }
        }, 2000);
    }
}

// Event listeners
btn.addEventListener('click', summarize);
downloadBtn.addEventListener('click', downloadPDF);

// Support Ctrl+Enter to submit
input.addEventListener('keydown', (e) => { 
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        summarize();
    }
});

// Add fade-in animation keyframes dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes fadeIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
`;
document.head.appendChild(style);